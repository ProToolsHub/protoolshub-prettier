class BrewPrettier < Formula
  desc "Formateur de code pour projets Homebrew et langages web"
  homepage "https://github.com/ProToolsHub/Brew_prettier"
  url "https://github.com/ProToolsHub/Brew_prettier/archive/v1.0.0.tar.gz"
  sha256 "PLACEHOLDER_HASH"  # Sera mis à jour après la création du tag
  license "MIT"

  depends_on "node"

  def install
    bin.install "brew-prettier.js" => "brew-prettier"
    chmod 0755, bin/"brew-prettier"

    # Créer les répertoires de configuration
    config_dir = "#{Dir.home}/.brew-prettier"
    tools_dir = "#{config_dir}/tools"

    unless Dir.exist?(config_dir)
      system "mkdir", "-p", tools_dir
    end
  end

  def post_install
    ohai "Brew Prettier installé avec succès !"
    ohai "Utilisez-le avec la commande 'brew-prettier'"
  end

  test do
    assert_match "Homebrew Code Formatter", shell_output("#{bin}/brew-prettier --version")
  end
end